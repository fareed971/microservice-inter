package com.bankuserservice.demo.dao;

import org.springframework.data.jpa.repository.JpaRepository;

import com.bankuserservice.demo.entity.Account;

public interface IBankAccount extends JpaRepository<Account, String> {

}
