package com.bankuserservice.demo.dao;

import org.springframework.data.jpa.repository.JpaRepository;

import com.bankuserservice.demo.entity.User;

public interface IBankuser extends JpaRepository<User, String>{

}
