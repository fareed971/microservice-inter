package com.bankuserservice.demo.service;

import org.springframework.stereotype.Service;

@Service
public class BankUserService {
	/*
	 * @Autowired private BankUserDao repository;
	 * 
	 * public UserBo getUserById(Integer id) {
	 * 
	 * return repository.findById(id).map(u -> { UserBo bo = new
	 * UserBo(u.getUserId(), u.getFirstName(), u.getLastName(), u.getEmail(),
	 * u.getPhoneNo(), u.getAddress1(), u.getAddress2(), u.getAccount()); return bo;
	 * }).orElseGet(null);
	 * 
	 * }
	 * 
	 * public List<UserBo> getUserList() {
	 * 
	 * return repository.findAll().stream().map(u -> { UserBo bo = new
	 * UserBo(u.getUserId(), u.getFirstName(), u.getLastName(), u.getEmail(),
	 * u.getPhoneNo(), u.getAddress1(), u.getAddress2(), u.getAccount()); return bo;
	 * }).collect(Collectors.toList());
	 * 
	 * }
	 * 
	 * public void saveUser(UserBo bo) {
	 * 
	 * User u = new User(); u.setUserId(bo.getUserId());
	 * u.setFirstName(bo.getFirstName()); u.setLastName(bo.getLastName());
	 * u.setEmail(bo.getEmail()); u.setPhoneNo(bo.getPhoneNo());
	 * u.setAddress1(bo.getAddress1()); u.setAddress2(bo.getAddress2());
	 * u.setAccount(bo.getAccount()); repository.save(u);
	 * 
	 * }
	 * 
	 * public void updateUser(UserBo bo) {
	 * 
	 * User user = new User(bo.getPhoneNo(), bo.getAddress1(), bo.getAddress2(),
	 * bo.getAccount()); repository.save(user);
	 * 
	 * }
	 * 
	 * public void deleteUser(UserBo bo) {
	 * 
	 * User user = new User(bo.getPhoneNo(), bo.getAddress1(), bo.getAddress2(),
	 * bo.getAccount()); repository.delete(user); }
	 */
}
